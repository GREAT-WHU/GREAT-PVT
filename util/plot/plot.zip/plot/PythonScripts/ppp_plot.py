import logging
import os
from tqdm import tqdm
from dependency.gnss_io.gnss_flt_io import readGreatFltFile_v2
from snx_to_crd import readCrdFile
from dependency.gnss_plot.gnss_great_draw_flt import gnss_great_draw_compare_flt

# siteList = [
#     "AC23", "AC24", "WUH2", "POTS", "GODN", "GODS", "MBAR", "SGOC", "ASCG", "PARK", "CPVG","ALIC","HERS"
# ]

siteList = [
    "HARB","GODN"
]

# Year of data
year = 2023
# DOY the data
day = 305
# Set data type: floating point solution (ppp-float) or fixed solution (ppp-fixed)
type1 = "PPP-float"
type2 = "PPP-fixed"

# Station data corresponding to type1
fltPath1 = rf".\data_ppp\kin_float"
# Station data corresponding to type2
fltPath2 = rf".\data_ppp\kin_fix"
# Saved results directory
savePath = rf".\output"
# gnss_crd_io.py crd file path output by the script
crdPath = rf".\data_ppp\crd\snx_igs_2023_305.crd"

crdData = readCrdFile(crdPath)
for doy in tqdm(range(day, day + 1)):
    yeardoy_savePath = os.path.join(savePath, f"{year:04d}_{doy:03d}")
    for site in siteList:
        logging.info(f"{site}")
        for i in range(1):
            fltFilePath1 = os.path.join(fltPath1, f"{site}-PPP.flt")
            fltFilePath2 = os.path.join(fltPath2, f"{site}-PPP.flt")
            if not os.path.exists(fltFilePath2):
                continue

            fltData2 = readGreatFltFile_v2(fltFilePath2)

            if not os.path.exists(fltFilePath1):
                continue
            fltData1 = readGreatFltFile_v2(fltFilePath1)
            gnss_great_draw_compare_flt(site, type1, type2, fltData1, fltData2, crdData, yeardoy_savePath)
