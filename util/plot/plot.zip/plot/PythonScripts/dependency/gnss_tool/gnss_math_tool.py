
from decimal import Decimal
import math

RE_WGS84 = 6378137.0           # earth semimajor axis (WGS84) (m)
FE_WGS84 = 1.0/298.257223563   # earth flattening (WGS84)
PI = 3.1415926535897932        # pi

# ==============================================
# Round according to the precision threshold
# ==============================================
def get_round(value, thrld):
    """
    Round, thrld = "0.001" or "0.01"
    """
    # Turn a number into a string
    strValue=str(value)
    # The number of Decimal places to keep is determined by the number of decimal places 
    # like the second decimal bracket, that is, two decimal places to keep, accurate to 0.01
    # If you want to round to keep integers, then the second parenthesis should be "1."
    a_int = Decimal(strValue).quantize(Decimal(thrld), rounding = "ROUND_HALF_UP")#保留后三位
    return a_int

# ==============================================
# averaging
# ==============================================
def get_average(records):
    """
    Mean value
    """
    if len(records) == 0:
        return 999
    else:
        return sum(records) / len(records)

# ==============================================
# Variance extraction
# ==============================================

def get_variance(records):
    """
    Variance reflects the degree of dispersion of a data set
    """
    average = get_average(records)
    if len(records) == 0:
        return 999
    else:
        return sum([(x - average) ** 2 for x in records]) / len(records)


# ==============================================
# Standard deviation
# ==============================================

def get_standard_deviation(records):
    """
    Standard deviation == mean square error reflects the dispersion of a data set
    """
    variance = get_variance(records)
    return math.sqrt(variance)


# ==============================================
# Take rms (root mean square error)
# ==============================================

def get_rms(records):
    """
    The root-mean-square value reflects the effective value rather than the mean value
    """
    if len(records) == 0:
        return 999.0
    else:
        return math.sqrt(sum([x ** 2 for x in records]) / len(records))
