# -*- coding:utf-8 -*-
from functools import wraps
from genericpath import isdir
import os
import sys

pyDirName, pyFileName = os.path.split(os.path.abspath(__file__))
sys.path.append(f"{pyDirName}/../")

########################################################################
# check file exist or not
########################################################################
def isFileExist(filePath):
    """
    Check whether the file path exists and return true or false
    """
    if not os.path.exists(filePath):
        return False
    else:
        return True
