# -*- coding: utf-8 -*-
# ===================================================================
# Read the pos file of GREAT output and plot it as a graph
#
# Histroy:
# 2023-08-14 jdhuang Added a function that only draws floating-point or fixed solutions, 
#                    where the color of the curve is determined by the Q value
# ===================================================================

from math import floor
import os
import sys

pyDirName, pyFileName = os.path.split(os.path.abspath(__file__))
sys.path.append(f"{pyDirName}/../")

from dependency.gnss_tool.gnss_math_tool import get_round


# ===================================================================
# To obtain a complete time index, it is mainly to consider the case of cross-week and epoch missing
# ===================================================================
def getPosTimeIndex(posData, intv):
    tmp_index = set()

    begTime = +9999
    endTime = -9999
    
    gpsw=0
        
    
    
    #pppflt
    for gpsw in posData:        
        for sow in posData[gpsw]:
            time = float(gpsw) + float(sow) / 10e6
            if begTime > time:
                begTime = time
            if endTime < time:
                endTime = time

    time_index = list()

    time = begTime
    gpsw = floor(time)
    while(True):
        gsow = (time - floor(time))  * 10e6
        if gsow > 86400 * 7:
            gpsw = gpsw + 1
            gsow = 1
        str_gpsw = f"{gpsw:04d}"
        str_gsow = get_round(float(gsow),"0.01")
        str_gsow = f"{int(str_gsow)}"
        time_index.append(str_gpsw + "." + str_gsow)
        if time > endTime:
            break

        time = time + intv / 10e6

    return time_index

